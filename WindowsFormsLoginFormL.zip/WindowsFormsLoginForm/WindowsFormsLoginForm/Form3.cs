﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsLoginForm
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataDataSet3.Person' table. You can move, or remove it, as needed.
            this.personTableAdapter.Fill(this.dataDataSet3.Person);
            // TODO: This line of code loads data into the 'dataDataSet2.Address' table. You can move, or remove it, as needed.
            this.addressTableAdapter.Fill(this.dataDataSet2.Address);

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
