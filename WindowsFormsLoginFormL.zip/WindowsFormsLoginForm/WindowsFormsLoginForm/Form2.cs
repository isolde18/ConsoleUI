﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsLoginForm
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent(); 
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataDataSet.Table' table. You can move, or remove it, as needed.
            this.tableTableAdapter.Fill(this.dataDataSet.Table);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //supposed to take you to the Form3 with the person info tables address and person 
            MessageBox.Show("Add the following information");
            this.Hide();
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}
