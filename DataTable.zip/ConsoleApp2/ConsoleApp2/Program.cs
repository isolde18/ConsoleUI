﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            using (DataTable dt = new DataTable("Test"))
            {
                dt.Columns.Add("ID", typeof(int));
                dt.Columns.Add("Dosage", typeof(int));
                dt.Columns.Add("Drug", typeof(string));
                dt.Columns.Add("Patient", typeof(string));
                dt.Columns.Add("Date", typeof(DateTime));
                dt.Rows.Add(1, 1, "Adderal", "David", DateTime.Now);
                dt.Rows.Add(2, 2, "Percoset", "Scott", DateTime.Now);
                dt.Rows.Add(3, 2,"Prozac", "Chris", DateTime.Now);
                dt.Rows.Add(4, 1,"Ambient", "Melanie", DateTime.Now);
                dt.Rows.Add(5, 2, "Elavil", "Jennifer", DateTime.Now);

                foreach(DataRow dr in dt.Rows)
                {
                    Console.WriteLine("ID ={4},Dosage ={0}, Drug ={1}, Patient ={2},Date ={3}", dr["ID"], dr["Dosage"], dr["Drug"], dr["Patient"], dr["Date"]);
                }

            }
            Console.ReadKey();
        }
    }
}
